# Especificações do código

- O arquivo "sync_fifo_tb.v" é o arquivo que está funcionando corretamente. Tem um print associado.
- O arquivo "sync_fifo_tb_test.v" possui outra implementação que estava tentando com o intuito de treinar diferentes formas de implementação. Gostaria que, se possível, o senhor apontasse os erros desta implementação. Tem um print associado.